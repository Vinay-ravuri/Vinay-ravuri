<!-- OPTIONAL: paste this into README.md AFTER you have added profile-stats.yml and run the workflow once. -->

## 📊 GitHub Stats

<div align="center">

<img src="./profile-summary-card-output/tokyonight/3-stats.svg" alt="GitHub stats" height="190"/>
<img src="./profile-summary-card-output/tokyonight/0-profile-details.svg" alt="Profile details" height="190"/>

<br/>

<img src="./profile-summary-card-output/tokyonight/2-most-commit-language.svg" alt="Most used languages" height="190"/>
<img src="./profile-summary-card-output/tokyonight/1-repos-per-language.svg" alt="Repos per language" height="190"/>

<br/><br/>

<img src="https://raw.githubusercontent.com/Vinay-ravuri/Vinay-ravuri/output/github-snake-dark.svg" alt="Contribution snake" width="100%"/>

</div>
